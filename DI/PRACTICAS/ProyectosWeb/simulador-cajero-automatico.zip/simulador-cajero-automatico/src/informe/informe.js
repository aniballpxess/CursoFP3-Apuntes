import { Record, loadRecords, saveRecords } from '../record.js';

document.addEventListener('DOMContentLoaded', () => {
    // --- UI ELEMENTS ---

    // Table parts
    /** @type {HTMLTableSectionElement} */
    const table_body = document.getElementById('records-table-body');

    // Action buttons
    /** @type {HTMLButtonElement} */
    const act_btn_reset = document.getElementById('act-btn-reset');
    /** @type {HTMLButtonElement} */
    const act_btn_exit = document.getElementById('act-btn-exit');

    // -------------------------------------------------------------------------- //

    // --- LOCAL DEFINITIONS ---

    // Constants
    /** @enum {string} */
    const EVENT = Object.freeze({
        CLICK: 'click',
        CHANGE: 'change',
        STORAGE: 'storage',
    });

    // Variables
    /** @type {Record[]} */
    let records = null;

    // Functions
    /**
     *
     */
    function loadTable() {
        table_body.replaceChildren();
        records.forEach(record => {
            const tr = document.createElement('tr');
            let td = null;

            td = document.createElement('td');
            td.textContent = record.date;
            td.className = 'with-text';
            tr.appendChild(td);

            td = document.createElement('td');
            td.textContent = record.time;
            td.className = 'with-text';
            tr.appendChild(td);

            td = document.createElement('td');
            td.textContent = record.action;
            td.className = 'with-text';
            tr.appendChild(td);

            td = document.createElement('td');
            td.textContent = record.withdrawal_amount;
            td.className = 'with-text';
            tr.appendChild(td);

            td = document.createElement('td');
            td.textContent = record.balance;
            td.className = 'with-text';
            tr.appendChild(td);

            table_body.appendChild(tr);
        });
    }

    // -------------------------------------------------------------------------- //

    // --- EVENT HANDLING ---

    // Action buttons
    act_btn_exit.addEventListener(EVENT.CLICK, () => {
        window.close();
    });
    act_btn_reset.addEventListener(EVENT.CLICK, () => {
        localStorage.removeItem('records');
        records = loadRecords();
        loadTable();
    });

    // Storage change
    window.addEventListener(EVENT.STORAGE, event => {
        if (event.key === 'records') {
            records = loadRecords();
            loadTable();
        }
    });

    // -------------------------------------------------------------------------- //

    // --- INCIALIZE INTERFACE ---
    records = loadRecords();
    loadTable();

    // -------------------------------------------------------------------------- //

    // --- TESTING ---
});
